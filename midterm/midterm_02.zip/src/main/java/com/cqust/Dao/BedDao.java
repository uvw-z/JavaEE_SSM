package com.cqust.Dao;

/**
 * @author yxt
 * @Description:
 * @date 2022/11/2 16:04
 */
public class BedDao {
}
